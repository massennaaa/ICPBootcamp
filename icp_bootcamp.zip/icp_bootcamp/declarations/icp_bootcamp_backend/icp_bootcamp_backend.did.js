export const idlFactory = ({ IDL }) => {
  const Candidate = IDL.Text;
  return IDL.Service({
    'checkVoterStatus' : IDL.Func([IDL.Text], [IDL.Bool], ['query']),
    'getCandidates' : IDL.Func([], [IDL.Vec(Candidate)], ['query']),
    'getResults' : IDL.Func(
        [],
        [
          IDL.Vec(
            IDL.Record({ 'voteCount' : IDL.Nat, 'candidate' : IDL.Text })
          ),
        ],
        ['query'],
      ),
    'getVotes' : IDL.Func([], [IDL.Vec(IDL.Nat)], ['query']),
    'vote' : IDL.Func([IDL.Nat, IDL.Text], [IDL.Text], []),
  });
};
export const init = ({ IDL }) => { return []; };
